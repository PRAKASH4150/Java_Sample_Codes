package edu.newhaven.smoka2.vowelcounter;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VowelCounterApplicationTests {

    @Test
    void contextLoads() {
    }

}
